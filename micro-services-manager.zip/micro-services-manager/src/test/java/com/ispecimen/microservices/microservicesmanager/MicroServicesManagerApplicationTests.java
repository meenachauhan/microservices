package com.ispecimen.microservices.microservicesmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicesManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
